package View;

import Models.Usuarios;
import Utils.Menus;
import Utils.utils;
import java.util.Scanner;

public class MainFernanShop {
    public static void main(String[] args) throws InterruptedException {
        var s = new Scanner(System.in);

        int op;
        String correo, contrasenia;

        Usuarios usuarios = new Usuarios();

        // menu principal
        do {
            System.out.print("""
        ╔════════════════════════════════╗
        ║         ¡¡BIENVENIDO!!         ║
        ╠════════════════════════════════╣
        ║ 1.- Iniciar sesión             ║
        ║ 2.- Regístrate                 ║
        ╚════════════════════════════════╝
        Introduce la opción deseada:\s""");
            op = Integer.parseInt(s.nextLine());

            switch (op) {
                case 1: // Iniciar sesion
                    utils.limpiaPantalla();
                    System.out.print("""
                            ╔════════════════════════════════════════════╗
                            ║              INICIO DE SESIÓN              ║
                            ╚════════════════════════════════════════════╝
                             * Introduce tu correo:\s""");
                    correo = s.nextLine();
                    System.out.print(" * Introduce la contraseña: ");
                    contrasenia = s.nextLine();
                    utils.limpiaPantalla();
                    if (!usuarios.login(correo, contrasenia)) System.out.println("Error, correo y/o contraseña incorrectos.\n");
                    else usuarios.verificaUsuario(correo, contrasenia);

                    break;
                case 2: // Registro para usuario
                    utils.limpiaPantalla();
                    if (!usuarios.hayHuecoCliente()) System.out.println("Lo sentimos, no tenemos espacio para más registros.");
                    else {
                        Menus.menuRegistro();
                        System.out.println("Su registro se ha completado exitosamente. Inicia sesión a continuación.");
                        utils.pulsaParaContinuar();
                        utils.limpiaPantalla();
                    }
                    break;
                default:
            }
        } while (op == 1 || op == 2);
    }
}
