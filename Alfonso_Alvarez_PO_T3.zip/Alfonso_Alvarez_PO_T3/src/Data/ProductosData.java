package Data;

import Models.Producto;

public class ProductosData {

    public static Producto producto1 = new Producto("El señor de los anillos (Trilogía), de J. R. R. Tolkien.", 49.99f, 20);
    public static Producto producto2 = new Producto("Harry Potter y la piedra filosofal de J. K. Rowling.", 16.10f, 20);
    public static Producto producto3 = new Producto("En busca del tiempo perdido, de Marcel Proust.", 19.95f, 20);
    public static Producto producto4 = new Producto("Paquete de 12 marcapáginas.", 7.99f, 20);
    public static Producto producto5 = new Producto("Paquete Folios A4 80gr.", 2.95f, 20);

}
