package Utils;

import Models.*;

import java.time.LocalDate;
import java.util.Scanner;

import static Data.ProductosData.*;
import static Models.Usuarios.*;

public class Menus {

    static Usuarios usuarios = new Usuarios();

    // Menu para el cliente
    public static void menuCliente(Cliente cliente) throws InterruptedException {
        utils.limpiaPantalla();
        var s = new Scanner(System.in);
        int op;

        do {
            System.out.printf("""
                    ╔═════════════════════════════════════════════╗
                    ║                  FERNANSHOP                 ║
                    ╠═════════════════════════════════════════════╣
                    ║ BIENVENIDO, %-31s ║
                    ╠═════════════════════════════════════════════╣
                    ║ 1.- Consultar el catálogo de productos      ║
                    ║ 2.- Realizar un pedido                      ║
                    ║ 3.- Ver mis pedidos realizados              ║
                    ║ 4.- Ver mis datos personales                ║
                    ║ 5.- Modificar mis datos personales          ║
                    ║ 6.- Cerrar sesión                           ║
                    ╚═════════════════════════════════════════════╝
                    Introduce la opción deseada:\s""",
                    cliente.getNombre());
            op = Integer.parseInt(s.nextLine());

            switch (op) {
                case 1: // Consultar el catálogo de productos
                    utils.limpiaPantalla();
                    System.out.println("""
                    ╔════════════════════════════════════════════════════════════════════╗
                    ║                        CATÁLOGO DE PRODUCTOS                       ║
                    ╚════════════════════════════════════════════════════════════════════╝
                    """);
                    System.out.println(producto1.pintaProducto());
                    System.out.println(producto2.pintaProducto());
                    System.out.println(producto3.pintaProducto());
                    System.out.println(producto4.pintaProducto());
                    System.out.println(producto5.pintaProducto());
                    utils.pulsaParaContinuar();
                    utils.limpiaPantalla();
                    break;
                case 2: // Realizar un pedido
                    if (producto1.getCantidad() <= 0 && producto2.getCantidad() <= 0 && producto3.getCantidad() <= 0 && producto4.getCantidad() <= 0 && producto5.getCantidad() <= 0)
                    System.out.println("No hay stock de ningún producto en este momento.");
                    else {
                        utils.limpiaPantalla();
                        int cont = 0, cantidad = 0;
                        boolean pedido = false;
                        String respuesta = "";
                        if (!cliente.hayHuecoPedido()) System.out.println("Lo sentimos, no se pueden realizar más de dos pedidos simultáneos");
                        else {
                            Pedido pedidoTemp = new Pedido();
                            do {
                                cont++;
                                System.out.println("""
                                        ╔═════════════════════════════════════════════════════════════╗╔═════════╗
                                        ║ PRODUCTOS                                                      PRECIO
                                        ╚═════════════════════════════════════════════════════════════╝╚═════════╝
                                        """);
                                System.out.println("1.-\n" + producto1.pintaProductoPedido());
                                System.out.println("2.-\n" + producto2.pintaProductoPedido());
                                System.out.println("3.-\n" + producto3.pintaProductoPedido());
                                System.out.println("4.-\n" + producto4.pintaProductoPedido());
                                System.out.println("5.-\n" + producto5.pintaProductoPedido());
                                System.out.print("Introducxe la opción deseada: ");
                                int opPedido = Integer.parseInt(s.nextLine());

                                if (opPedido >= 1 && opPedido <= 5) {
                                    System.out.print("Introduce la cantidad a comprar: ");
                                    cantidad = Integer.parseInt(s.nextLine());
                                }

                                switch (opPedido) {
                                    case 1: // Producto 1
                                        pedido = false;
                                        if (producto1.getCantidad() <= 0) System.out.println("Error, no hay stock de este producto.");
                                        else if (cantidad > producto1.getCantidad())
                                            System.out.println("No se puede realizar la venta ya que la cantidad introducida supera el stock actual");
                                        else {
                                            pedido = true;
                                            producto1.restacantidad(cantidad);
                                            Producto productoTemp = new Producto(producto1.getNombre(), producto1.getPrecio(), cantidad);
                                            pedidoTemp.agregaProducto(productoTemp);
                                        }
                                        break;
                                    case 2: // Producto 2
                                        pedido = false;
                                        if (producto2.getCantidad() <= 0) System.out.println("Error, no hay stock de este producto.");
                                        else if (cantidad > producto2.getCantidad())
                                            System.out.println("No se puede realizar la venta ya que la cantidad introducida supera el stock actual");
                                        else {
                                            pedido = true;
                                            producto2.restacantidad(cantidad);
                                            Producto productoTemp = new Producto(producto2.getNombre(), producto2.getPrecio(), cantidad);
                                            pedidoTemp.agregaProducto(productoTemp);
                                        }
                                        break;
                                    case 3: // Producto 3
                                        pedido = false;
                                        if (producto3.getCantidad() <= 0) System.out.println("Error, no hay stock de este producto.");
                                        else if (cantidad > producto3.getCantidad())
                                            System.out.println("No se puede realizar la venta ya que la cantidad introducida supera el stock actual");
                                        else {
                                            pedido = true;
                                            producto3.restacantidad(cantidad);
                                            Producto productoTemp = new Producto(producto3.getNombre(), producto3.getPrecio(), cantidad);
                                            pedidoTemp.agregaProducto(productoTemp);
                                        }
                                        break;
                                    case 4: // Producto 4
                                        pedido = false;
                                        if (producto4.getCantidad() <= 0) System.out.println("Error, no hay stock de este producto.");
                                        else if (cantidad > producto4.getCantidad())
                                            System.out.println("No se puede realizar la venta ya que la cantidad introducida supera el stock actual");
                                        else {
                                            pedido = true;
                                            producto4.restacantidad(cantidad);
                                            Producto productoTemp = new Producto(producto4.getNombre(), producto4.getPrecio(), cantidad);
                                            pedidoTemp.agregaProducto(productoTemp);
                                        }
                                        break;
                                    case 5: // Producto 5
                                        pedido = false;
                                        if (producto5.getCantidad() <= 0) System.out.println("Error, no hay stock de este producto.");
                                        else if (cantidad > producto5.getCantidad())
                                            System.out.println("No se puede realizar la venta ya que la cantidad introducida supera el stock actual");
                                        else {
                                            pedido = true;
                                            producto5.restacantidad(cantidad);
                                            Producto productoTemp = new Producto(producto5.getNombre(), producto5.getPrecio(), cantidad);
                                            pedidoTemp.agregaProducto(productoTemp);
                                        }
                                        break;
                                    default:
                                        System.out.println("Error, introduce una opción del catálogo.");
                                }

                                if (pedido) {
                                    if (cont != 3) {
                                        System.out.print("¿Quieres añadir otro producto al carrito? (S/N): ");
                                        respuesta = s.nextLine();
                                        utils.limpiaPantalla();
                                    }
                                }

                            } while (cont <= 2 && respuesta.equalsIgnoreCase("S"));

                            System.out.println("Su pedido se ha realizado correctamente");

                            cliente.agregaPedido(pedidoTemp);
                        }
                    }

                    break;
                case 3: // Ver mis pedidos realizados
                    utils.limpiaPantalla();
                    if (cliente.getPedido1() == null) System.out.println("Pedido no realizado");
                    else {
                        System.out.println(cliente.pintaPedidoParaCliente(cliente.getPedido1()));
                        if (cliente.getPedido2() == null) System.out.println(" ");
                        else System.out.println(cliente.pintaPedidoParaCliente(cliente.getPedido2()));
                    }
                    utils.pulsaParaContinuar();
                    break;
                case 4: // Ver mis datos personales
                    utils.limpiaPantalla();
                    System.out.println(cliente.pintaDatosCliente());
                    utils.pulsaParaContinuar();
                    break;
                case 5: // Modificar mis datos personales
                    utils.limpiaPantalla();
                    System.out.println("Introduce tu contraseña para acceder.");
                    String contrasenia = s.nextLine();
                    if (!cliente.verificaContrasenia(contrasenia)) System.out.println("La contraseña introducida no es corecta.");
                    else {
                        do {

                            System.out.print("""
                                    ╔══════════════════════════════════════════╗
                                    ║              MENÚ DE OPCIONES            ║
                                    ╠══════════════════════════════════════════╣
                                    ║ 1.- Nombre.                              ║
                                    ║ 2.- 1er Apellido.                        ║
                                    ║ 3.- Teléfono.                            ║
                                    ║ 4.- Correo.                              ║
                                    ║ 5.- Contraseña.                          ║
                                    ║ 6.- Provincia.                           ║
                                    ║ 7.- Localidad.                           ║
                                    ║ 8.- Dirección.                           ║
                                    ║ 9.- SALIR.                               ║
                                    ╚══════════════════════════════════════════╝
                                    Selecciona el apartado que quieras modificar:\s""");
                            op = Integer.parseInt(s.nextLine());

                            switch (op) {
                                case 1: // Cambiar nombre
                                    System.out.print("Introduce tu nuevo nombre: ");
                                    String nombre = s.nextLine();
                                    cliente.setNombre(nombre);
                                    System.out.println("Su nombre se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 2: // Cambiar apellido
                                    System.out.print("Introduce tu nuevo apellido: ");
                                    String apellido = s.nextLine();
                                    cliente.setApellido1(apellido);
                                    System.out.println("Su apellido se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 3: // Cambiar telefono
                                    System.out.print("Introduce tu nuevo número de teléfono: ");
                                    int telefono = Integer.parseInt(s.nextLine());
                                    if (!cliente.verificaTelefono(telefono))
                                        System.out.println("El teléfono introducido no cumple con el formato establecido");
                                    else {
                                        cliente.setTelefono(telefono);
                                        System.out.println("Su teléfono se ha cambiado correctamente.");
                                    }
                                    utils.pulsaParaContinuar();
                                    break;
                                case 4: // Cambiar correo
                                    System.out.print("Introduce tu nuevo correo: ");
                                    String correo = s.nextLine();
                                    cliente.setCorreo(correo);
                                    System.out.println("Su correo se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 5: // Cambiar contraseña
                                    System.out.print("Introduce tu nueva contraseña: ");
                                    String clave = s.nextLine();
                                    if (!cliente.mideContrasenia(clave))
                                        System.out.println("La longitud de la contraseña debe ser mayor o igual a 4");
                                    else {
                                        cliente.setContrasenia(clave);
                                        System.out.println("Su contraseña se ha cambiado correctamente.");
                                    }
                                    utils.pulsaParaContinuar();
                                    break;
                                case 6: // Cambiar provincia
                                    System.out.print("Introduce tu nuevo provincia: ");
                                    String provincia = s.nextLine();
                                    cliente.setProvincia(provincia);
                                    System.out.println("Su provincia se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 7: // Cambiar localidad
                                    System.out.print("Introduce tu nueva localidad: ");
                                    String localidad = s.nextLine();
                                    cliente.setLocalidad(localidad);
                                    System.out.println("Su localidad se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 8: // Cambiar direccion
                                    System.out.print("Introduce tu nueva direccion: ");
                                    String direccion = s.nextLine();
                                    cliente.setDireccion(direccion);
                                    System.out.println("Su dirección se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 9: // Salir
                                    utils.saliendo();
                                    utils.limpiaPantalla();
                                    break;
                                default:
                                    System.out.println("ERROR. Seleccione uno de los apartados a modificar.");
                            }
                        } while (op != 9);
                    }
                    break;
                case 6: // Cerrar sesion
                    utils.limpiaPantalla();
                    utils.saliendo();
                    utils.limpiaPantalla();
                    break;
                default:
            }
        } while (op != 6);
    }

    // Menu para el trabajador
    public static void menuTrabajador(Trabajador trabajador) throws InterruptedException {
        utils.limpiaPantalla();

        var s = new Scanner(System.in);
        int op;

        do {
            System.out.printf("""
        ╔═══════════════════════════════════════════════╗
        ║                   FERNANSHOP                  ║
        ╠═══════════════════════════════════════════════╣
        ║ Bienvenido, %-32s  ║
        ║ Tienes %d pedidos que gestionar.               ║
        ╠═══════════════════════════════════════════════╣
        ║ 1.- Consultar los pedidos que tengo asignados ║
        ║ 2.- Modificar el estado de un pedido          ║
        ║ 3.- Consultar el catálogo de productos        ║
        ║ 4.- Modificar un producto del catálogo        ║
        ║ 5.- Ver mi perfil                             ║
        ║ 6.- Modificar mis datos personales            ║
        ║ 7.- Cerrar sesión                             ║
        ╚═══════════════════════════════════════════════╝
        Introduce la opción deseada:\s""",
                    trabajador.getNombre(), trabajador.sumaPedidosAsignados());
            op = Integer.parseInt(s.nextLine());

            switch (op) {
                case 1: // Consultar los pedidos que tengo asignados
                    utils.limpiaPantalla();
                    if (trabajador.getPedidoAsignado1() == null) {
                        System.out.println("No hay pedidos asignados");
                    } else {
                        System.out.println(trabajador.pintaPedidoAsignado(trabajador.getPedidoAsignado1()));
                    }

                    if (trabajador.getPedidoAsignado2() == null) {
                        if (trabajador.getPedidoAsignado1() != null) {
                            System.out.println("No hay más pedidos asignados");
                        }
                    } else {
                        System.out.println(trabajador.pintaPedidoAsignado(trabajador.getPedidoAsignado2()));
                    }
                    break;
                case 2: // Modificar el estado de un pedido
                    utils.limpiaPantalla();
                    String opcion;
                    if (cliente1 == null && cliente2 == null) System.out.println("No hay clientes registrados");
                    else {
                        if (cliente1.getPedido1() == null && cliente1.getPedido2() == null && cliente2.getPedido1() == null && cliente2.getPedido2() == null)
                            System.out.println("No se ha realizado ningún pedido");
                        else {
                            utils.limpiaPantalla();
                            if (trabajador.getPedidoAsignado1() != null) System.out.println(trabajador.pintaPedidoAsignado(trabajador.getPedidoAsignado1()));

                            if (trabajador.getPedidoAsignado2() != null) System.out.println(trabajador.pintaPedidoAsignado(trabajador.getPedidoAsignado2()));

                            System.out.print("Introduce el código del pedido al que le quieres cambiar el estado: ");
                            opcion = s.nextLine();

                            if (!usuarios.cambiaEstado(opcion)) System.out.println("Error, hubo un problema con la búsqueda del pedido.");
                            else System.out.println("Estado cambiado correctamente.");
                        }
                    }
                    break;
                case 3: // Consultar el catálogo de productos
                    utils.limpiaPantalla();
                    System.out.println("======== CATÁLOGO DE PRODUCTOS ========\n");
                    System.out.println("1.-\n" + producto1.pintaProducto());
                    System.out.println("2.-\n" + producto2.pintaProducto());
                    System.out.println("3.-\n" + producto3.pintaProducto());
                    System.out.println("4.-\n" + producto4.pintaProducto());
                    System.out.println("5.-\n" + producto5.pintaProducto());
                    System.out.println();
                    utils.pulsaParaContinuar();
                    utils.limpiaPantalla();
                    break;
                case 4: // Modificar un producto del catálogo
                    utils.limpiaPantalla();
                    int opStock, cantidad = 0;
                    do {
                        utils.limpiaPantalla();
                        System.out.println("1.- El señor de los anillos (Trilogía), de J. R. R. Tolkien. Cantidad en stock: " + producto1.getCantidad());
                        System.out.println("2.- Harry Potter y la piedra filosofal (Harry Potter 1) de J. K. Rowling. Cantidad en stock: " + producto2.getCantidad());
                        System.out.println("3.- En busca del tiempo perdido, de Marcel Proust. Cantidad en stock: " + producto3.getCantidad());
                        System.out.println("4.- Paquete de 12 marcapáginas. Cantidad en stock: " + producto4.getCantidad());
                        System.out.println("5.- Paquete Folios A4 80gr, 100 unidades. Cantidad en stock: " + producto5.getCantidad());
                        System.out.println("6.- Salir.");

                        System.out.print("Introduce la opción deseada: ");
                        opStock = Integer.parseInt(s.nextLine());

                        if (opStock >= 1 && opStock <= 5) {
                            do {
                                System.out.print("Introduce la cantidad deseada para aumentar el stock: ");
                                cantidad = Integer.parseInt(s.nextLine());
                                if (cantidad <= 0) System.out.println("Error, debes introducir un valor superior a 0.");
                            } while (cantidad <= 0);
                        }

                        switch (opStock) {
                            case 1: // Sumar stock a producto 1
                                producto1.sumaCantidad(cantidad);
                                break;
                            case 2: // Sumar stock a producto 2
                                producto2.sumaCantidad(cantidad);
                                break;
                            case 3: // Sumar stock a producto 3
                                producto3.sumaCantidad(cantidad);
                                break;
                            case 4: // Sumar stock a producto 4
                                producto4.sumaCantidad(cantidad);
                                break;
                            case 5: // Sumar stock a producto 5
                                producto5.sumaCantidad(cantidad);
                                break;
                            case 6: // Salir
                                utils.saliendo();
                                utils.limpiaPantalla();
                                break;
                            default:
                                System.out.println("Error, introduce un dato de la lista de productos.");
                        }
                        if (opStock != 6) System.out.println("La cantidad se ha añadido correctamente.");
                    } while (opStock != 6);

                    break;
                case 5: // Ver mi perfil
                    utils.limpiaPantalla();
                    System.out.println(trabajador.pintaDatosTrabajador());
                    utils.pulsaParaContinuar();
                    break;
                case 6: // Modificar mis datos personales
                    utils.limpiaPantalla();
                    System.out.println("Introduce tu contraseña para acceder.");
                    String contrasenia = s.nextLine();
                    if (!trabajador.verificaContrasenia(contrasenia)) System.out.println("La contraseña introducida no es corecta.");
                    else {
                        do {

                            System.out.print("""
                        1.- Nombre.
                        2.- Correo.
                        3.- Contraseña.
                        4.- SALIR.
                        
                        Selleciona el apartado que quieras modificar:\s""");
                            op = Integer.parseInt(s.nextLine());

                            switch (op) {
                                case 1: // Cambiar nombre trabajador
                                    System.out.print("Introduce tu nuevo nombre: ");
                                    String nombre = s.nextLine();
                                    trabajador.setNombre(nombre);
                                    System.out.println("Su nombre se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 2: // Cambiar correo trabajador
                                    System.out.print("Introduce tu nuevo correo: ");
                                    String correo = s.nextLine();
                                    trabajador.setCorreo(correo);
                                    System.out.println("Su correo se ha cambiado correctamente.");
                                    utils.pulsaParaContinuar();
                                    break;
                                case 3: // Cambiar contraseña trabajador
                                    System.out.print("Introduce tu nueva contraseña: ");
                                    String clave = s.nextLine();
                                    if (!trabajador.mideContrasenia(clave))
                                        System.out.println("La longitud de la contraseña debe ser mayor o igual a 4");
                                    else {
                                        trabajador.setContrasenia(clave);
                                        System.out.println("Su contraseña se ha cambiado correctamente.");
                                    }
                                    utils.pulsaParaContinuar();
                                    break;
                                case 4: // Salir
                                    utils.saliendo();
                                    utils.limpiaPantalla();
                                    break;
                                default:
                                    System.out.println("ERROR. Seleccione uno de los apartados a modificar.");
                            }
                        } while (op != 4);
                    }
                    break;
                case 7: // Cerrar sesion
                    utils.limpiaPantalla();
                    utils.saliendo();
                    utils.limpiaPantalla();
                    break;
                default:

            }
        } while (op != 7);
    }

    // Menu para el administrador
    public static void menuAdministrador() throws InterruptedException {
        utils.limpiaPantalla();

       var s = new Scanner(System.in);
       int op;
       String opCodigo, opcion;

       do {
           System.out.printf("""
        ╔════════════════════════════════════════════════╗
        ║                   FERNANSHOP                   ║
        ╠════════════════════════════════════════════════╣
        ║ Bienvenido ADMIN.                              ║
        ║ Tienes %d pedidos por asignar.                  ║
        ╠════════════════════════════════════════════════╣
        ║ 1.- Asignar un pedido a un trabajador          ║
        ║ 2.- Modificar el estado de un pedido           ║
        ║ 3.- Dar de alta un trabajador                  ║
        ║ 4.- Ver todos los pedidos                      ║
        ║ 5.- Ver todos los clientes                     ║
        ║ 6.- Ver todos los trabajadores                 ║
        ║ 7.- Cerrar sesión                              ║
        ╚════════════════════════════════════════════════╝
        Introduce la opción deseada:\s""", usuarios.sumaPedidosAdmin());
           op = Integer.parseInt(s.nextLine());

           switch (op) {
               case 1: // Asinar un pedido a un trabajador

                           boolean hayPedido = false;
                           utils.limpiaPantalla();
                           int opTrabajador;
                           if (cliente1 == null && cliente2 == null) System.out.println("No hay clientes registrados");
                           else {
                               hayPedido = true;
                               if (cliente1.getPedido1() == null) System.out.println("El cliente " + cliente1.getNombre() + " no ha realizado ningún pedido.");
                               else {
                                   System.out.println("- " + cliente1.getPedido1().getCodigo() + ", " + cliente1.getNombre() +
                                           ", " + cliente1.getApellido1() + ", " + "(" + cliente1.getLocalidad() + ")" + " - " +
                                           cliente1.getPedido1().cuentaProductos() + " productos" + " - " +
                                           cliente1.getPedido1().sumaPrecioTotal() + " Euros.");
                               }
                               if (cliente1.getPedido2() == null) System.out.println(" ");
                               else {
                                   System.out.println("- " + cliente1.getPedido2().getCodigo() + ", " + cliente1.getNombre() +
                                           ", " + cliente1.getApellido1() + ", " + "(" + cliente1.getLocalidad() + ")" + " - " +
                                           cliente1.getPedido2().cuentaProductos() + " productos" + " - " +
                                           cliente1.getPedido2().sumaPrecioTotal() + " Euros.");
                               }

                               if (cliente2 == null) System.out.println(" ");
                               else {
                                   if (cliente2.getPedido1() == null) System.out.println("El cliente " + cliente2.getNombre() + " no ha realizado ningún pedido.");
                                   else {
                                       System.out.println("- " + cliente2.getPedido1().getCodigo() + ", " + cliente2.getNombre() +
                                               ", " + cliente2.getApellido1() + ", " + "(" + cliente2.getLocalidad() + ")" + " - " +
                                               cliente2.getPedido1().cuentaProductos() + " productos" + " - " +
                                               cliente2.getPedido1().sumaPrecioTotal() + " Euros.");
                                   }
                                   if (cliente2.getPedido2() == null) System.out.println(" ");
                                   else {
                                       System.out.println("- " + cliente2.getPedido2().getCodigo() + ", " + cliente2.getNombre() +
                                               ", " + cliente2.getApellido1() + ", " + "(" + cliente2.getLocalidad() + ")" + " - " +
                                               cliente2.getPedido2().cuentaProductos() + " productos" + " - " +
                                               cliente2.getPedido2().sumaPrecioTotal() + " Euros.");
                                   }
                               }
                           }

                           if (hayPedido) {
                               do {
                                   System.out.print("Seleccione el código del pedido que quiere asignar: ");
                                   opCodigo = s.nextLine();
                               } while (!opCodigo.equals("0001") && !opCodigo.equals("0002") && !opCodigo.equals("0003") && !opCodigo.equals("0004"));

                               usuarios.seleccionaPedido(opCodigo);

                               if (usuarios.seleccionaPedido(opCodigo) == null) System.out.println("El código introducido no coincide con ningún pedido.");
                               else {
                                   do {
                                       System.out.println("=== Asignación del pedido " + usuarios.seleccionaPedido(opCodigo).getCodigo() + " ===");

                                       if (trabajador1 == null) System.out.println("No hay trabajadores");
                                       else System.out.println("1.- Nombre: " + trabajador1.getNombre() + " - " + trabajador1.sumaPedidosAsignados() + " pedidos en proceso.");

                                       if (trabajador2 == null) System.out.println(" ");
                                       else System.out.println("2.- Nombre: " + trabajador2.getNombre() + " - " + trabajador2.sumaPedidosAsignados() + " pedidos en proceso.");

                                       if (trabajador3 == null) System.out.println(" ");
                                       else System.out.println("3.- Nombre: " + trabajador3.getNombre() + " - " + trabajador3.sumaPedidosAsignados() + " pedidos en proceso.");

                                       System.out.print("Seleccione el trabajador: ");
                                       opTrabajador = Integer.parseInt(s.nextLine());

                                       switch (opTrabajador) {
                                           case 1:
                                               if (trabajador1 != null) trabajador1.asignaPedido(usuarios.seleccionaPedido(opCodigo));
                                               else System.out.println(" ");
                                               break;
                                           case 2:
                                               if (trabajador2 != null) trabajador2.asignaPedido(usuarios.seleccionaPedido(opCodigo));
                                               else System.out.println(" ");
                                               break;
                                           case 3:
                                               if (trabajador3 != null) trabajador3.asignaPedido(usuarios.seleccionaPedido(opCodigo));
                                               else System.out.println(" ");
                                               break;
                                           default:
                                               System.out.println("Error, introduce una opción válida.");
                                       }
                                   } while (opTrabajador <= 0 || opTrabajador >= 4);
                                   System.out.println("Pedido asignado correctamente");
                               }
                           }
                   utils.pulsaParaContinuar();
                   utils.limpiaPantalla();

                   break;
               case 2: // Modificar el estado de un pedido
                   utils.limpiaPantalla();
                   if (cliente1 == null && cliente2 == null) System.out.println("No hay clientes registrados");
                   else {
                       if (cliente1.getPedido1() == null && cliente1.getPedido2() == null && cliente2.getPedido1() == null && cliente2.getPedido2() == null)
                           System.out.println("No se ha realizado ningún pedido");
                       else {
                               utils.limpiaPantalla();
                               if (cliente1.getPedido1() != null) System.out.println(cliente1.pintaPedidoParaAdmin(cliente1.getPedido1()));

                               if (cliente1.getPedido2() != null) System.out.println(cliente1.pintaPedidoParaAdmin(cliente1.getPedido2()));

                               if (cliente2 != null && cliente2.getPedido1() != null) System.out.println(cliente2.pintaPedidoParaAdmin(cliente2.getPedido1()));

                               if (cliente2 != null && cliente2.getPedido2() == null) System.out.println(cliente2.pintaPedidoParaAdmin(cliente2.getPedido2()));


                               System.out.print("Introduce el código del pedido al que le quieres cambiar el estado: ");
                               opcion = s.nextLine();

                               if (!usuarios.cambiaEstado(opcion)) System.out.println("Error, hubo un problema con la búsqueda del pedido.");
                               else System.out.println("Estado cambiado correctamente.");

                       }
                   }
                   utils.pulsaParaContinuar();
                   utils.limpiaPantalla();
                   break;
               case 3: // Dar de alta un trabajador
                   utils.limpiaPantalla();
                   String nombre, correo, contrasenia;
                   if (!usuarios.hayHuecoTrabajador()) System.out.println("Lo sentimos, no quedan plazas para más trabajadores.");
                   else {
                       System.out.print("Introduce el nombre del trabajador: ");
                       nombre = s.nextLine();
                       System.out.print("Introduce el correo del trabajador: ");
                       correo = s.nextLine();
                       System.out.print("Introduce la contraseña del trabajador: ");
                       contrasenia = s.nextLine();

                       Trabajador trabajadorTemp = new Trabajador(nombre, correo, contrasenia);

                       usuarios.darAltaTrabajador(trabajadorTemp);

                       utils.pulsaParaContinuar();
                   }
                   break;
               case 4: // Ver todos los pedidos
                   utils.limpiaPantalla();
                   if (cliente1 == null && cliente2 == null) System.out.println("No hay clientes registrados");
                   else usuarios.pintaPedidos();
                   utils.pulsaParaContinuar();
                   utils.limpiaPantalla();
                   break;
               case 5: // Ver todos los clientes
                   utils.limpiaPantalla();
                   if (cliente1 == null && cliente2 == null) {
                       System.out.println("No hay clientes registrados.");
                       utils.pulsaParaContinuar();
                   }
                   else {
                       System.out.println("╔═════════════════════════════════════════════╗");
                       System.out.println("║                   CLIENTES                  ║");
                       System.out.println("╚═════════════════════════════════════════════╝");
                       System.out.println(cliente1 == null ? " " : cliente1.pintaClienteAdmin());
                       System.out.println(cliente2 == null ? " " : cliente2.pintaClienteAdmin());
                       utils.pulsaParaContinuar();
                   }
                   break;
               case 6: // Ver todos los trabajadores
                   utils.limpiaPantalla();
                   if (trabajador1 == null && trabajador2 == null && trabajador3 == null) {
                       System.out.println("Todavía no hay trabajadores registrados.");
                       utils.pulsaParaContinuar();
                   }
                   else {
                       System.out.println("╔══════════════════════════════════════════════╗");
                       System.out.println("║                 TRABAJADORES                 ║");
                       System.out.println("╚══════════════════════════════════════════════╝");
                       System.out.println(trabajador1 == null ? " " : trabajador1.pintaTrabajadorAdmin(trabajador1));
                       System.out.println(trabajador2 == null ? " " : trabajador2.pintaTrabajadorAdmin(trabajador2));
                       System.out.println(trabajador3 == null ? " " : trabajador3.pintaTrabajadorAdmin(trabajador3));
                       utils.pulsaParaContinuar();
                   }
                   break;
               case 7: // Cerrar sesion
                   utils.limpiaPantalla();
                   utils.saliendo();
                   utils.limpiaPantalla();
                   break;
               default:

           }
       } while (op != 7);
    }

    // Menu de registro
    public static void menuRegistro() {
        utils.limpiaPantalla();

        var s = new Scanner(System.in);

        System.out.print("""
        ╔═════════════════════════════════════════════╗
        ║             REGISTRO DE USUARIO             ║
        ╚═════════════════════════════════════════════╝
         * Introduce tu nombre:\s""");
        String nombre = s.nextLine();
        System.out.print(" * Introduce tu primer apellido: ");
        String apellido1 = s.nextLine();
        System.out.print(" * Introduce tu teléfono: ");
        int telefono = Integer.parseInt(s.nextLine());
        System.out.print(" * Introduce tu correo: ");
        String correo = s.nextLine();
        System.out.print(" * Introduce la contraseña: ");
        String contrasenia = s.nextLine();
        System.out.print(" * Introduce tu provincia: ");
        String provincia = s.nextLine();
        System.out.print(" * Introduce tu localidad: ");
        String localidad = s.nextLine();
        System.out.print(" * Introduce tu direccion: ");
        String direccion = s.nextLine();

        Cliente clienteTemp = new Cliente(nombre, apellido1, telefono, correo, contrasenia,
                provincia, localidad, direccion);

        usuarios.registraCliente(clienteTemp);
    }

    // Menu de cambio de estado de pedido
    public static void cambiaEstadoPedido(Pedido pedido) {
        var s = new Scanner(System.in);
        int opEstado;
        do {
            System.out.print("""
                    Nuevo estado:
                    1.- Recibido.
                    2.- En preparación.
                    3.- Retrasado.
                    4.- Cancelado.
                    5.- Enviado
                    Seleccione el nuevo estado:\s""");
            opEstado = Integer.parseInt(s.nextLine());

            switch (opEstado) {
                case 1:
                    pedido.setEstado("Recibido");
                    break;
                case 2:
                    pedido.setEstado("En preparación");
                    break;
                case 3:
                    pedido.setEstado("Retrasado");
                    break;
                case 4:
                    pedido.setEstado("Cancelado");
                    break;
                case 5:
                    pedido.setEstado("Enviado");
                    break;
            }
        } while (opEstado <= 0 || opEstado >= 6);
    }

    // Menu de cambio de comentario y fecha
    public static void menuCambiaDatos(Pedido pedido) {

        var s = new Scanner(System.in);

        System.out.print("Quieres agregar un comentario? (S/N): ");
        String respuesta = s.nextLine();

        if (respuesta.equalsIgnoreCase("s")) {
            System.out.print("Introduce el nuevo comentario: ");
            String comentario = s.nextLine();
            pedido.setComentario(comentario);
        }

        System.out.print("Quieres cambiar la fecha del pedido? (S/N): ");
        respuesta = s.nextLine();

        if (respuesta.equalsIgnoreCase("s")) {
            LocalDate fecha;
            do {
                System.out.print("Introduce la nueva fecha en este formato (yyyy-mm-dd): ");
                fecha = LocalDate.parse(s.nextLine());
                if (fecha.isBefore(pedido.getFechaPedido())) System.out.println("Debes introducir una fecha posterior a la fecha inicial");
                else pedido.setFechaPedido(fecha);
            } while (fecha.isBefore(pedido.getFechaPedido()));
        }
    }
}
