package Utils;

import java.util.Scanner;

public class utils {

    public static void pulsaParaContinuar() {
        var s = new Scanner(System.in);
        System.out.print("Pulsa 'Enter' para continuar...");
        s.nextLine();
    }

    public static void limpiaPantalla() {
        for (int i = 0; i < 100; i++) {
            System.out.println();
        }
    }

    public static void saliendo() throws InterruptedException {
        System.out.print("Saliendo");
        for (int i = 0; i < 3; i++) {
            Thread.sleep(700);
            System.out.print(".");
        }
    }
}
