package Models;

import Utils.Menus;

public class Usuarios {

    // Atributos
    private final Admin admin = new Admin();
    public static Cliente cliente1;
    public static Cliente cliente2;
    public static Trabajador trabajador1;
    public static Trabajador trabajador2;
    public static Trabajador trabajador3;

    // Metodo que verifica si hay hueco para un nuevo cliente
    public boolean hayHuecoCliente() {
        return cliente1 == null || cliente2 == null;
    }

    // Este metodo inserta los datos recogidos en uno de los clientes siempre y cuando haya hueco disponible
    public void registraCliente(Cliente cliente) {
        if (!hayHuecoCliente()) return;
        if (cliente1 == null) {
            cliente1 = new Cliente(cliente);
            return;
        }
        cliente2 = new Cliente(cliente);
    }

    // Metodo que verifica si hay hueco para un nuevo trabajador
    public boolean hayHuecoTrabajador() {
        return trabajador1 == null || trabajador2 == null || trabajador3 == null;
    }

    public void darAltaTrabajador(Trabajador trabajador) {
        if (!hayHuecoTrabajador()) return;
        if (trabajador1 == null) {
            trabajador1 = new Trabajador(trabajador);
            return;
        }
        if (trabajador2 == null) {
            trabajador2 = new Trabajador(trabajador);
            return;
        }
        if (trabajador3 == null) {
            trabajador3 = new Trabajador(trabajador);
        }
    }

    // Metodo que verifica si la contraseña coincide con el correo
    public boolean login(String correo, String contrasenia) {
        if (admin.getCorreo().equals(correo) && admin.getContrasenia().equals(contrasenia)) {
            return true;
        } else if (cliente1 != null && cliente1.getCorreo().equals(correo) && cliente1.getContrasenia().equals(contrasenia)) {
            return true;
        } else if (cliente2 != null && cliente2.getCorreo().equals(correo) && cliente2.getContrasenia().equals(contrasenia)) {
            return true;
        } else if (trabajador1 != null && trabajador1.getCorreo().equals(correo) && trabajador1.getContrasenia().equals(contrasenia)) {
            return true;
        } else if (trabajador2 != null && trabajador2.getCorreo().equals(correo) && trabajador2.getContrasenia().equals(contrasenia)) {
            return true;
        } else if (trabajador3 != null && trabajador3.getCorreo().equals(correo) && trabajador3.getContrasenia().equals(contrasenia)) {
            return true;
        }
        return false;
    }

    // Metodo que asigna un menu dependiendo del correo y la contraseña
    public void verificaUsuario(String correo, String contrasenia) throws InterruptedException {
        if (admin.getCorreo().equals(correo) && admin.getContrasenia().equals(contrasenia)) {
            Menus.menuAdministrador();
        } else if (cliente1 != null && cliente1.getCorreo().equals(correo) && cliente1.getContrasenia().equals(contrasenia)) {
            Menus.menuCliente(cliente1);
        } else if (cliente2 != null && cliente2.getCorreo().equals(correo) && cliente2.getContrasenia().equals(contrasenia)) {
            Menus.menuCliente(cliente2);
        } else if (trabajador1 != null && trabajador1.getCorreo().equals(correo) && trabajador1.getContrasenia().equals(contrasenia)) {
            Menus.menuTrabajador(trabajador1);
        } else if (trabajador2 != null && trabajador2.getCorreo().equals(correo) && trabajador2.getContrasenia().equals(contrasenia)) {
            Menus.menuTrabajador(trabajador2);
        } else if (trabajador3 != null && trabajador3.getCorreo().equals(correo) && trabajador3.getContrasenia().equals(contrasenia)) {
            Menus.menuTrabajador(trabajador3);
        }
    }

    // Metodo que permite elegir un pedido segun su codigo
    public Pedido seleccionaPedido(String opCodigo) {
        if (cliente1.getPedido1() != null && cliente1.getPedido1().getCodigo().equals(opCodigo))
            return cliente1.getPedido1();
        else if (cliente1.getPedido2() != null && cliente1.getPedido2().getCodigo().equals(opCodigo))
            return cliente1.getPedido2();
        else if (cliente2.getPedido1() != null && cliente2.getPedido1().getCodigo().equals(opCodigo))
            return cliente2.getPedido1();
        else if (cliente2.getPedido2() != null && cliente2.getPedido2().getCodigo().equals(opCodigo))
            return cliente2.getPedido2();
        return null;
    }

    // Metodo que pinta los pedidos realizados
    public void pintaPedidos() {
        if (cliente1.getPedido1() == null) System.out.println(" ");
        else System.out.println(cliente1.pintaPedidoParaAdmin(cliente1.getPedido1()));
        if (cliente1.getPedido2() == null) System.out.println(" ");
        else System.out.println(cliente1.pintaPedidoParaAdmin(cliente1.getPedido2()));
        if (cliente2 != null) {
            if (cliente2.getPedido1() == null) System.out.println(" ");
            else System.out.println(cliente2.pintaPedidoParaAdmin(cliente2.getPedido1()));
            if (cliente2.getPedido2() == null) System.out.println(" ");
            else System.out.println(cliente2.pintaPedidoParaAdmin(cliente2.getPedido2()));
        }
    }

    // Metodo que permite cambiar el estado de un pedido
    public boolean cambiaEstado(String opcion) {
        if (cliente1 != null) {
            if (cliente1.getPedido1() != null && cliente1.getPedido1().getCodigo().equals(opcion)) {
                Menus.cambiaEstadoPedido(cliente1.getPedido1());
                Menus.menuCambiaDatos(cliente1.getPedido1());
                return true;
            } else if (cliente1.getPedido2() != null && cliente1.getPedido2().getCodigo().equals(opcion)) {
                Menus.cambiaEstadoPedido(cliente1.getPedido2());
                Menus.menuCambiaDatos(cliente1.getPedido2());
                return true;
            } else return false;

        } else if (cliente2 != null) {
            if (cliente2.getPedido1() != null && cliente2.getPedido1().getCodigo().equals(opcion)) {
                Menus.cambiaEstadoPedido(cliente2.getPedido1());
                Menus.menuCambiaDatos(cliente2.getPedido1());
                return true;
            } else if (cliente2.getPedido2() != null && cliente2.getPedido2().getCodigo().equals(opcion)) {
                Menus.cambiaEstadoPedido(cliente2.getPedido2());
                Menus.menuCambiaDatos(cliente2.getPedido2());
                return true;
            } else return false;
        } return false;
    }

    // Metodo que cuenta los pedidos que tiene el administrador asignados
    public int sumaPedidosAdmin() {
        int cont = 0;

        if (cliente1 != null && cliente1.getPedido1() != null) cont++;
        if (cliente1 != null && cliente1.getPedido2() != null) cont++;
        if (cliente2 != null && cliente2.getPedido1() != null) cont++;
        if (cliente2 != null && cliente2.getPedido2() != null) cont++;

        return cont;
    }
}
